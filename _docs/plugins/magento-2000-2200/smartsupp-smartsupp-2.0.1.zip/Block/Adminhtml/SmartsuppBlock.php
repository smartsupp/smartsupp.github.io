<?php

namespace Smartsupp\Smartsupp\Block\Adminhtml;

use Magento\Backend\Block\Template;

/**
 * SmartsuppBlock Template Class.
 *
 * @category Class
 * @package  Smartsupp
 * @author   Smartsupp <vladimir@smartsupp.com>
 * @license  http://opensource.org/licenses/gpl-license.php GPL-2.0+
 * @link     http://www.smartsupp.com
 */
class SmartsuppBlock extends Template
{
}
