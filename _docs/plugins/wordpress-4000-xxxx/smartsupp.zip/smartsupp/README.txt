=== Smartsupp Live Chat ===
Contributors: Smartsupp
Donate link:
Tags: banckle, Casengo, chat, chat for web, chat online, chat software, click desk, clickdesk, freshdesk, free chat, free live chat, IM Chat, jivochat, jivosite, live chat, live chat inc, live support, live web chat, livechat, olark, online chat, online support, snapengage, wordpress chat, wordpress live chat, Zendesk, Zopim, Tawk.to, Happyfox chat, Smartsupp, Smartsup, Smartsapp, Boldchat, Live person, pure chat, chatra
Requires at least: 3.1
Tested up to: 4.9
Stable tag: 3.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Smartsupp is free live chat with visitor recording. Your customers are on your website right now. Chat with them and see what they do.

== Description ==

= Smartsupp is free live chat with visitor recording. =

Smartsupp plugin supports visitor identification - you can display visitor info (like name, email, customer's VIP status) in Smartsupp, where you see it while chatting. This way you know are chatting with e.g. Tom Smith, who already spent 800 EUR on your website. Visitor has to be signed in on your website for you to be able to see the info.

= Smartsupp product video (shorther than 1 minute): =

[youtube http://www.youtube.com/watch?v=g88XoQW9V7U]

With Smartsupp you can chat with visitors in real-time and also watch their behavior on your website - you see screen, mouse movement and clicks of every visitor.

= Smartsupp is available in following languages: =

* English
* Español
* Français
* Deutsch
* Nederlands
* Polski
* Česky
* Italiano
* Magyar
* Dansk
* Русский

More info at https://www.smartsupp.com.

== Installation ==

= Requires: =
Wordpress 3.1 or higher, PHP at least 5.3.

= Instalation steps =
1. Install Smartsupp plugin in Wordpress and activate it
2. Login to Smartsupp or create new account in plugin settings
3. Now Smartsupp chat is visible on your website. Sign in to Smartsupp dashboard and start chatting with your visitors.

= Installation tutorial with screenshots: =
https://www.smartsupp.com/help/wordpress

== Frequently Asked Questions ==

== Screenshots ==

1. Plugin settings

2. Chat window - visible to customers

3. Chat administration - visible to chat operators

== Changelog ==

= 3.2 =
* Fixed bug when SCRIPT tags are inserted into optional code text area
* Some minor text changes

= 3.1 =
* Fixed bug on some installations with WooCommerce
* Fixed bug with custom templates not showing styles

= 3.0 =
* Refactored plugin design

= 2.8 =
* Fixed some PHP warnings

= 2.7 =
* Updated dependencies
* Fixed problem with some non-ASCII letters used in strings

= 2.6 =
* PHP version check. At least PHP 5.3 is required during plugin activation.
* Wordpress version check for at least version 3.1
* Removed some PHP warnings

= 2.5 =
* settings page changes

= 2.4 =
* version fix

= 2.3 =
* Some default parameters are not set
* Possibility to enter custom parameters for chat

= 2.2 =
* Some language changes

= 2.1 =
* fixed error in rendering

= 2.0 =
* Plugin is using now smartsupp/chat-code-generator (https://github.com/smartsupp/chat-code-generator)

= 0.1 =
* Inital version of the Plugin
